import random
import json
import pickle
import numpy as np
import nltk
import re
from nltk.stem import WordNetLemmatizer
from transformers import GPT2Tokenizer, GPT2LMHeadModel
import torch
from tensorflow.keras.models import load_model
from flask import Flask, render_template
from flask_socketio import SocketIO, emit

# Initialize the Flask app and socketio
app = Flask(__name__)
socketio = SocketIO(app)

# Load the NLTK tools
lemmatizer = WordNetLemmatizer()

# Load your pre-trained Keras model
model = load_model('chatbotmodel.h5')

# Load GPT-2 model and tokenizer
gpt_model = GPT2LMHeadModel.from_pretrained('gpt2')
tokenizer = GPT2Tokenizer.from_pretrained('gpt2')

# Load your intents, words, and classes
intents = json.loads(open('intents.json').read())
words = pickle.load(open('words.pkl', 'rb'))
classes = pickle.load(open('classes.pkl', 'rb'))

# Define common questions and answers
common_questions = {
    "What are your opening hours?": "We are open from 9 AM to 5 PM, Monday to Friday.",
    "hours":"We are open from 9 AM to 5 PM, Monday to Friday.",
    "opening hours":"We are open from 9 AM to 5 PM, Monday to Friday.",
    "Where are you located?": "We are located at 123 Main Street, Anytown, USA.",
    "How can I contact you?": "You can contact us at contact@college.edu or call us at (123) 456-7890.",
    "contact":"You can contact us at contact@college.edu or call us at (123) 456-7890.",
    "how to contact":"You can contact us at contact@college.edu or call us at (123) 456-7890.",
    "What courses do you offer?": "We offer a variety of courses in Science, Arts, and Technology. Please visit our website for more details.",
    "How do I apply?": "You can apply online through our application portal. Visit our website and click on 'Apply Now'.",
    "apply": "You can apply online through our application portal. Visit our website and click on 'Apply Now'.",
    "how to apply":"You can apply online through our application portal. Visit our website and click on 'Apply Now'.",
    "What facilities do you have?": "Our campus facilities include a library, gymnasium, cafeteria, and sports fields.",
    "Can you tell me about campus life?": "Campus life is vibrant with various clubs, events, and student organizations.",
    "campus":"Campus life is vibrant with various clubs, events, and student organizations.",
    "campus life":"Campus life is vibrant with various clubs, events, and student organizations.",
    "What are your admission requirements?": "Admission requirements vary by program. Please visit our admissions page for detailed information.",
    "Do you offer scholarships?": "Yes, we offer scholarships based on academic merit and financial need. Please check our scholarships page for details.",
    "scholarships":"Yes, we offer scholarships based on academic merit and financial need. Please check our scholarships page for details.",
    "What majors are popular at your college?": "Popular majors include Computer Science, Business Administration, and Psychology.",
    "Is there on-campus housing available?": "Yes, we offer on-campus housing options. You can find more information on our housing page.",
    "Can I visit campus?": "Yes, you can schedule a campus tour through our website. We look forward to showing you around!"
}

@app.route('/')
def index():
    return render_template('index.html')

@socketio.on('message')
def handle_message(message):
    print('received message:', message)
    try:
        if is_common_question(message):
            response = get_common_response(message)
        elif is_math_expression(message):
            response = evaluate_math_expression(message)
        else:
            intent = predict_class(message)
            if intent and float(intent[0]['probability']) > 0.25:
                response = get_response(intent, intents)
            else:
                response = generate_gpt_response(message)
        emit('response', response)
    except Exception as e:
        print(f"Error in handling message: {e}")
        emit('response', "I'm sorry, something went wrong.")

def clean_up_sentence(sentence):
    sentence_words = nltk.word_tokenize(sentence)
    sentence_words = [lemmatizer.lemmatize(word) for word in sentence_words]
    return sentence_words

def bag_of_words(sentence):
    sentence_words = clean_up_sentence(sentence)
    bag = [0] * len(words)
    for w in sentence_words:
        for i, word in enumerate(words):
            if word == w:
                bag[i] = 1
    return np.array(bag)

def predict_class(sentence):
    bow = bag_of_words(sentence)
    res = model.predict(np.array([bow]))[0]
    ERROR_THRESHOLD = 0.25
    results = [[i, r] for i, r in enumerate(res) if r > ERROR_THRESHOLD]

    results.sort(key=lambda x: x[1], reverse=True)
    return_list = []
    for r in results:
        return_list.append({'intent': classes[r[0]], 'probability': str(r[1])})
    return return_list

def get_response(intents_list, intents_json):
    tag = intents_list[0]['intent']
    list_of_intents = intents_json['intents']
    for i in list_of_intents:
        if i['tag'] == tag:
            result = random.choice(i['responses'])
            break
    return result

def generate_gpt_response(prompt):
    try:
        inputs = tokenizer.encode(prompt, return_tensors='pt')
        outputs = gpt_model.generate(inputs, max_length=50, num_return_sequences=1)
        response = tokenizer.decode(outputs[0], skip_special_tokens=True)
        return response
    except Exception as e:
        print(f"Error in generating GPT response: {e}")
        return "I'm sorry, I couldn't generate a response."

def is_math_expression(message):
    # Improved regex to detect mathematical expressions
    pattern = re.compile(r'^[\d\s\+\-\*\/\(\)\.]+$')
    return bool(pattern.match(message))

def evaluate_math_expression(expression):
    try:
        # Safely evaluate the expression
        result = eval(expression, {"__builtins__": {}}, {})
        return f"The result is: {result}"
    except Exception as e:
        print(f"Error in evaluating expression: {e}")
        return "I'm sorry, I couldn't evaluate the expression."

def is_common_question(message):
    return message in common_questions

def get_common_response(message):
    return common_questions.get(message, "I'm sorry, I don't have information on that right now.")

if __name__ == '__main__':
    app.run()

print("|============= Welcome to College Enquiry Chatbot System! =============|")
print("|============================== Feel Free ============================|")
print("|================================== To ===============================|")
print("|=============== Ask any query about our college ================|")

while True:
    message = input("| You: ")
    if message.lower() in ["bye", "goodbye"]:
        ints = predict_class(message)
        res = get_response(ints, intents)
        print("| Bot:", res)
        print("|===================== The Program End here! =====================|")
        break
    else:
        if is_common_question(message):
            res = get_common_response(message)
        elif is_math_expression(message):
            res = evaluate_math_expression(message)
        else:
            ints = predict_class(message)
            if len(ints) > 0 and float(ints[0]['probability']) > 0.25:
                res = get_response(ints, intents)
            else:
                res = generate_gpt_response(message)
        print("| Bot:", res)
